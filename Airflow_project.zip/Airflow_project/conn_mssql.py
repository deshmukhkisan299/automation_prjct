import pyodbc

# Set up the connection parameters
server = 'LAPTOP-3PM0G1M7\SQLEXPRESS'
database = 'airflow_project'
username = 'your_username'
password = 'your_password'

# Establish the connection
cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};Server=LAPTOP-3PM0G1M7\SQLEXPRESS;'
                                                                          'Trusted_connection=yes;'
                                                                        'Database = airflow_project;')

# Create a cursor object
cursor = cnxn.cursor()

# Execute a sample query
cursor.execute('create table sample(id int,name varchar(20))')

# Fetch the results
rows = cursor.fetchall()

# Print the results
for row in rows:
    print(row)

# Close the cursor and connection
cursor.close()
cnxn.close()
